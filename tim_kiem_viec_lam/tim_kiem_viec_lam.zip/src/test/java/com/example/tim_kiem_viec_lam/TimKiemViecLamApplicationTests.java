package com.example.tim_kiem_viec_lam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimKiemViecLamApplicationTests {

	@Test
	void contextLoads() {
	}

}
