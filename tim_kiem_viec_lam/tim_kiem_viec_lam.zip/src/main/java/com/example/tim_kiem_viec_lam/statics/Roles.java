package com.example.tim_kiem_viec_lam.statics;

public enum Roles {

    USER,
    ADMIN,
    RECRUITER;

}
