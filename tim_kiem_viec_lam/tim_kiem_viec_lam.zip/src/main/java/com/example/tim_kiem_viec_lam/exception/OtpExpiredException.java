package com.example.tim_kiem_viec_lam.exception;

public class OtpExpiredException extends  Throwable{
}
