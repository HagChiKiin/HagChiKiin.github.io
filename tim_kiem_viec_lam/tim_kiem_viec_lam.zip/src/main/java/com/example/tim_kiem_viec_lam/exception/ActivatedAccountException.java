package com.example.tim_kiem_viec_lam.exception;

public class ActivatedAccountException extends Throwable{
    public ActivatedAccountException(String message) {
        super(message);
    }
}
